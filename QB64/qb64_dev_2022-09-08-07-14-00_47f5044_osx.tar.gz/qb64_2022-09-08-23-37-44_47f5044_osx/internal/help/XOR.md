See [Bitwise Operators](Bitwise-Operators).
