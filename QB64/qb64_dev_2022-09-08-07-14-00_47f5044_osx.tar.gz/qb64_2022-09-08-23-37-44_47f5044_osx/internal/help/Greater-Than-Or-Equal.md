The **>=** condition symbol denotes that a value must be greater than or equal to another value for the condition to be True. 

## Syntax

> IF x [>=](Greater-Than-Or-Equal) 320 THEN PRINT "Right or center of screen"

## See Also

* [Equal](Equal)
* [Not_Equal](Not-Equal)
* [Less_Than_Or_Equal](Less-Than-Or-Equal)
* [Relational Operations](Relational-Operations)
