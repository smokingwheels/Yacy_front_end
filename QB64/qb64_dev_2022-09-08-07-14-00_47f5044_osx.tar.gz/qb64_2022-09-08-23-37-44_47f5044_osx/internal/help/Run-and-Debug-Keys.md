* Start program execution from beginning - Shift + F5
* Continue program execution from current statement - F5
* Execute program to current cursor position - F7
---
* Execute next program statement as a single step - F8
* Single step, tracing around procedure calls - F10
---
* Set or clear a breakpoint - F9
