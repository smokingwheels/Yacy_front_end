* View Help for the item where the cursor is located - F1 (or right click)
* Exit Help - Esc
---
* View Using Help - Shift + F1
* Display the Help menu - Alt + H
---
* Move cursor to next Help topic - Tab
* Move cursor to previous Help topic - Shift + Tab
* Move cursor to next topic with starting character - character
* Move cursor to previous topic with starting character - Shift + character
* View previous Help topic (can repeat up to 20 times) - Alt + F1 (or click the *Back* button)
---
View the next topic in the Help file - Ctrl + F1
View the previous topic in the Help file - Shift + Ctrl + F1
