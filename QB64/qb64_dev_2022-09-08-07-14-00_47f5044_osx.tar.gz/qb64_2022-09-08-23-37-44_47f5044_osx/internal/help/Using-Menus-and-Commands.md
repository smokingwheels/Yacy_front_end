Use the menu bar at the top of the screen to select menus and commands.

| Menu action       | With a mouse...           | With a keyboard...        |
| ----------------- | ------------------------- | --------------------------|
| Display a menu.   | Move the mouse pointer to | Press Alt to highlight    |
|                   | the menu name, then press | menu letters, then press  |
|                   | and release ('click') the | the letter key for the    |
|                   | mouse button.             | menu you want to display. |
|                   |                           |                           |
| Choose a command. | Click the command name.   | Press the letter key that |
|                   |                           | matches the highlighted   |
|                   |                           | letter on the command.    |
|                   |                           |                           |
| Cancel a command. | Click outside the menu.   | Press Esc.                |

Tip: Check the reference bar at the bottom of the screen for help on your 
     current task. Choose any item in angle brackets by clicking the item.