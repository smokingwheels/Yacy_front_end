## Syntax

> **_GLRENDER ***mode*

## Parameters

Mode can be:

* _BEHIND - renders OpenGL context behind the software rendering
* _ONTOP - renders OpenGL context on the top of the software rendering [default]
* _ONLY -  renders OpenGL context only

## See Also

* [Hardware images](Hardware-images)
