'Negation is the process of changing the sign of a positive number to negative.

Usage: number% = -number%

Negation can be performed by adding a negative (- minus) sign to a number or by multiplying or dividing a number by any negative value.
If a negative value is negated, the value of the number becomes positive.

## See Also

* [*](multiplication), [/](division)
* [\](Integer-division)
* [Mathematical Operations](Mathematical-Operations)
