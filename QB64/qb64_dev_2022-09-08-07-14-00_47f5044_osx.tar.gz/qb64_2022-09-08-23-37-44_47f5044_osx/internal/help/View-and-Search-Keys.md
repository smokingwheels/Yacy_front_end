* Switch between the output screen and the View Window - F4
---
* Display a list of loaded SUB procedures - F2
* Display the next procedure - Shift + F2
* Display the previous procedure - Ctrl + F2
---
* Make the next window the active window - F6
* Make the previous window the active window - Shift + F6
---
* Switch between multiple windows and full-screen active window - Ctrl + F10
* Increase size of active window - Alt + Plus
* Decrease size of active window - Alt + Minus
---
* Repeat find for same text - Ctrl + L or F3
* Search for text - Ctrl + Q, F
* Search for and replace text - Ctrl + Q, A
