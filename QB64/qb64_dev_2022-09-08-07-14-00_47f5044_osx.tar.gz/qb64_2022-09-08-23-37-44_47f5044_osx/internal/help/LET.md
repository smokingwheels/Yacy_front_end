The [LET](LET) is a useless statement designed by [cavemen](cavemen) when they started programming.

## Syntax

> [**LET**] variable = expression

## Description

* `LET a = 12` is the same as `a = 12`, but wastes 4 extra bytes of program space. 
* [LET](LET) is **optional**, it's the only keyword where the **entire keyword** is optional :-)

## See Also
 
* [Cavemen](Cavemen)
* [Variable](Variable)
